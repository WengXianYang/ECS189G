# ECS 189G: Can LLMs Predict A/B Test Results, and Do They Know When They're Wrong?

Team: Gaeun Yu, Yurun Shi, Xian Yang Weng

We evaluate off-the-shelf LLMs on predicting the winners of real headline A/B tests (Upworthy Research Archive),
with Reddit same-image resubmissions as a second, observational domain. Focus: accuracy, calibration, the cost of
skipping tests when the model is confident, and in which settings predictions work.

## Repository layout
```
scripts/        data-prep and experiment scripts
data/raw/       original downloads (not committed; see below)
data/upworthy/  Upworthy pairs, dev/test split, test hash
data/reddit/    Reddit pairs and counts
docs/           data notes and decisions
```

## Data
| Dataset | Source | Notes |
|---|---|---|
| Upworthy Research Archive | https://osf.io/jd64p/ | Public subset; drop tests flagged in the 2024 update |
| Reddit submissions (SNAP) | https://metromaps.stanford.edu/data/web-Reddit.html | Download `redditSubmissions.csv.gz` into `data/raw/` |

Raw files are not committed. Download them into `data/raw/` and rebuild with the scripts.

## Rebuild
```
python scripts/reddit_pairs.py data/raw/redditSubmissions.csv.gz data/reddit/
```
Details and counts: [docs/README_reddit.md](docs/README_reddit.md).

## Rules
- The test set is locked after the split (hash recorded). Prompt tuning and thresholds use dev only.
- Reported numbers come from the merged results only.
